MEDIA MANAGER AI
================

WINDOWS
-------
1. Unzip this folder somewhere you keep programs (for example Documents\MediaManagerAI).
2. Double-click  "Start Media Manager.bat".
   The first time it installs, for your Windows user only (no admin needed):
     - Python 3.12 (only if you don't have Python yet)
     - the Claude library
     - ffmpeg (lets the AI look inside videos and measure their quality)
     - ffsubsync (optional, for "Auto-sync" of subtitles)
   It also puts a "Media Manager AI" shortcut on your desktop.
   Later starts open the app straight away.
3. In the app, click "Settings (API keys)" and paste:
     - your Anthropic API key  (https://console.anthropic.com/)
     - your free Subdl key      (https://subdl.com/)  - for subtitles

If Windows shows "Windows protected your PC", click "More info" -> "Run anyway".
(This happens with any downloaded .bat file.)

Want a single .exe for another PC?  Run "Build EXE.bat" (after step 2).
The result is in the "dist" folder.

MAC / LINUX
-----------
    pip install anthropic
    install ffmpeg  (Mac: brew install ffmpeg   Linux: sudo apt install ffmpeg python3-tk)
    python3 media_manager_ai.py

To start over, delete the hidden ".venv" folder and the ".ffmpeg_tried" file
next to the app, then start it again.
