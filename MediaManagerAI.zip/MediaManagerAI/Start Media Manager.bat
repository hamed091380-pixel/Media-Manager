@echo off
rem ======================================================================
rem  Media Manager AI - double-click this file to start the app.
rem  The first time, it installs what the app needs (Python, the Claude
rem  library, ffmpeg) for your Windows user only - no admin needed.
rem ======================================================================
setlocal
title Media Manager AI
cd /d "%~dp0"
set "VENV=%~dp0.venv"
set "PATH=%LOCALAPPDATA%\Microsoft\WinGet\Links;%PATH%"

if exist "%VENV%\Scripts\pythonw.exe" goto check_ffmpeg

echo.
echo  First start: setting things up. This happens only once
echo  and can take a few minutes. Please keep this window open.
echo.

call :find_python
if defined PY goto make_venv
echo  [1/4] Python is not installed. Installing Python 3.12 ...
where winget >nul 2>nul || goto no_winget
winget install -e --id Python.Python.3.12 --scope user --silent --accept-package-agreements --accept-source-agreements
call :find_python
if not defined PY goto python_failed

:make_venv
echo  [2/4] Creating the app's own Python folder ...
"%PY%" -m venv "%VENV%" || goto python_failed
"%VENV%\Scripts\python.exe" -m pip install --quiet --upgrade pip
echo  [3/4] Installing the Claude library ...
"%VENV%\Scripts\python.exe" -m pip install --quiet anthropic || goto pip_failed
echo  [4/4] Installing the subtitle auto-sync tool (optional) ...
"%VENV%\Scripts\python.exe" -m pip install --quiet ffsubsync >nul 2>nul || echo        Skipped - the "Auto-sync" option will be turned off.
call :make_shortcut

:check_ffmpeg
where ffmpeg >nul 2>nul && goto run
if exist "%~dp0ffmpeg\bin\ffmpeg.exe" goto run
if exist "%~dp0.ffmpeg_tried" goto run
echo  Installing ffmpeg (lets the AI look inside videos and measure their quality) ...
echo tried> "%~dp0.ffmpeg_tried"
where winget >nul 2>nul || goto ffmpeg_manual
winget install -e --id Gyan.FFmpeg --silent --accept-package-agreements --accept-source-agreements
where ffmpeg >nul 2>nul || goto ffmpeg_manual

:run
start "" "%VENV%\Scripts\pythonw.exe" "%~dp0media_manager_ai.py"
exit /b 0

rem ---------------------------------------------------------------- helpers
:find_python
set "PY="
for /f "delims=" %%P in ('py -3 -c "import sys, tkinter; print(sys.executable)" 2^>nul') do set "PY=%%P"
if defined PY exit /b 0
for /f "delims=" %%P in ('python -c "import sys, tkinter; print(sys.executable)" 2^>nul') do set "PY=%%P"
if defined PY exit /b 0
for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do if exist "%%D\python.exe" set "PY=%%D\python.exe"
exit /b 0

:make_shortcut
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Media Manager AI.lnk'); $s.TargetPath='%~f0'; $s.WorkingDirectory='%~dp0'; $s.WindowStyle=7; $s.IconLocation='%SystemRoot%\System32\imageres.dll,18'; $s.Save()" >nul 2>nul
if not errorlevel 1 echo        A "Media Manager AI" shortcut was added to your desktop.
exit /b 0

rem ---------------------------------------------------------------- problems
:ffmpeg_manual
echo.
echo  Could not install ffmpeg automatically. The app still works, but the AI
echo  cannot look inside videos. To add it by hand: download "ffmpeg-release-essentials.zip"
echo  from https://www.gyan.dev/ffmpeg/builds/ , unzip it, rename the folder to "ffmpeg"
echo  and put it next to this file (so that ffmpeg\bin\ffmpeg.exe exists).
echo.
pause
goto run

:no_winget
echo.
echo  Python is needed but could not be installed automatically.
echo  Please install it from https://www.python.org/downloads/
echo  (tick "Add python.exe to PATH"), then double-click this file again.
echo.
pause
exit /b 1

:python_failed
echo.
echo  Python could not be set up. Please install Python from
echo  https://www.python.org/downloads/ and double-click this file again.
echo  If you just installed it, close this window and try once more.
echo.
if exist "%VENV%" rmdir /s /q "%VENV%"
pause
exit /b 1

:pip_failed
echo.
echo  Could not download the Claude library. Check your internet connection
echo  and double-click this file again.
echo.
if exist "%VENV%" rmdir /s /q "%VENV%"
pause
exit /b 1
