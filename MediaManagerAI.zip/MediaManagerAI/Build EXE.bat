@echo off
rem ======================================================================
rem  Optional: builds ONE file, MediaManagerAI.exe, that you can copy to
rem  another Windows PC and run without installing Python.
rem  Run "Start Media Manager.bat" once first.
rem ======================================================================
setlocal
title Build Media Manager AI .exe
cd /d "%~dp0"
set "PATH=%LOCALAPPDATA%\Microsoft\WinGet\Links;%PATH%"
if not exist ".venv\Scripts\python.exe" goto not_ready

echo  Installing the EXE builder (PyInstaller) ...
".venv\Scripts\python.exe" -m pip install --quiet pyinstaller || goto failed
echo  Building - this takes a minute or two ...
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onefile --windowed --name MediaManagerAI media_manager_ai.py || goto failed

rem Put ffmpeg next to the .exe so the AI can look inside videos on the other PC too.
for %%T in (ffmpeg ffprobe) do for /f "delims=" %%P in ('where %%T 2^>nul') do copy /y "%%P" "dist\%%T.exe" >nul
if exist "ffmpeg\bin\ffmpeg.exe" copy /y "ffmpeg\bin\ffmpeg.exe" "dist\" >nul
if exist "ffmpeg\bin\ffprobe.exe" copy /y "ffmpeg\bin\ffprobe.exe" "dist\" >nul

echo.
echo  Done. Your app is in the "dist" folder:
echo     dist\MediaManagerAI.exe   (plus ffmpeg.exe and ffprobe.exe if found)
echo  Copy the whole "dist" folder to share it. Note: the subtitle auto-sync
echo  option is not included in the .exe version.
echo.
explorer "%~dp0dist"
pause
exit /b 0

:not_ready
echo.
echo  Please double-click "Start Media Manager.bat" once first, then run this again.
echo.
pause
exit /b 1

:failed
echo.
echo  The build failed - see the messages above.
echo.
pause
exit /b 1
